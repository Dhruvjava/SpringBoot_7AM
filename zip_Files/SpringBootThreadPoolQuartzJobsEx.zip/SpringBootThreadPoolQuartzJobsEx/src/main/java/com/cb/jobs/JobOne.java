package com.cb.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

public class JobOne implements Job {

    @Autowired
    private ThreadPoolTaskExecutor executor;

    @Override
    @Async
    public void execute(JobExecutionContext context) throws JobExecutionException {
        List<String> names = Arrays.asList("Dhruv", "Chaitanya", "Sekhar", "Rajesh", "Anil", "Raju", "Swamy", "Pawan", "mani", "Shiva");
        int threads = executor.getMaxPoolSize();
        int partitions = (int)Math.ceil(names.size()/(double) threads);
        AtomicInteger counter = new AtomicInteger(0);

        IntStream.range(0, threads)
                .forEach(i -> {
                    List<String> partition = names.subList(i* partitions,Math.min((i+1)*partitions,names.size()));
                    executor.execute(()-> {
                        for (int j = 0; j< partition.size(); j+=2){
                            String str1 = partition.get(j);
                            String str2 = (j+1 < partition.size()) ? partition.get(j+1) :null;
                            xyz(str1, str2);
                        }
                        counter.incrementAndGet();
//                        if (counter.get() == threads){
//                            executor.shutdown();
//                        }
                    });
                });
    }

    public void xyz(String i, String names) {
        System.out.println("Job One is running with thread : numbers -> " + i + " names : " + names);
    }
}