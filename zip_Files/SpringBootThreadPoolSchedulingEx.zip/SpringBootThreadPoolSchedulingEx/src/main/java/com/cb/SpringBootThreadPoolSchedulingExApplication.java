package com.cb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThreadPoolSchedulingExApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootThreadPoolSchedulingExApplication.class, args);
    }

}
